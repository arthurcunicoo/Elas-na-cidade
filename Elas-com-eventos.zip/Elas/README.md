# ELAS na cidade — fundo novo e animações

App mobile com React Native, TypeScript, Expo SDK 55 e Expo Router.

## Iniciar

Extraia o ZIP em uma pasta nova. Dentro de Elas, execute:

```sh
npm ci
npx expo start --clear
```

Requer Node.js 22 LTS ou superior e Expo Go compatível com SDK 55, ou um ambiente nativo configurado. A prévia no navegador pode ser aberta com `npx expo start --web`. Os componentes do app continuam sendo React Native.

## O que mudou nesta versão

- Fundo substituído pelo JPG fornecido, em `assets/city-modern.jpg`.
- Imagem preserva proporções e preenche a área da cidade, recortando as laterais quando necessário.
- Movimento horizontal lento do cenário com margem de imagem para não mostrar bordas.
- Subida com mola amortecida das boas-vindas para os formulários. Login e cadastro mantêm a mesma altura da cidade.
- Entrada do logo e dos campos em sequência, repetida ao retornar à tela.
- Botões comprimem no toque e retornam com mola.
- Transição visual entre a cidade e a área vinho dos formulários.
- Fundo de navegação transparente e inputs sem contorno retangular laranja.
- Redução de movimento respeitada; loops e animações são interrompidos ao desmontar.

## Estrutura

- `app/index.tsx`: boas-vindas.
- `app/login.tsx`: login.
- `app/cadastro.tsx`: cadastro.
- `components/CitySkyline.tsx`: cenário compartilhado e animado.
- `components/MotionReveal.tsx`: entrada dos elementos ao focar uma tela.
- `components/PrimaryButton.tsx`: botão com resposta ao toque.
- `hooks/useReducedMotion.ts`: preferência de acessibilidade.

O logo usa o recorte visual da screenshot original. Login abre o Perfil de demonstração; cadastro valida os campos, anima a saída do formulário e retorna ao login; não há autenticação nem transmissão de dados.

## Verificação

TypeScript e exportação Metro/Hermes Android e iOS. Sem execução visual em emulador ou celular neste ambiente; o resultado visual e o comportamento do teclado ainda precisam ser conferidos no dispositivo.

```sh
npm run typecheck
npx expo export --platform android --platform ios
```

## Ajuste das emendas

A transição da imagem para o fundo usa `expo-linear-gradient`, com opacidade total nas bordas e as cores exatas do fundo. As antigas faixas sobrepostas foram removidas. O topo mistura a imagem com o creme e a base termina em vinho sólido antes da junção.

`constants/cityLayout.ts` centraliza as medidas: login e cadastro compartilham o mesmo nível de cidade e início do formulário. As demais animações permanecem.

Ao atualizar, execute `npm ci` para instalar a dependência do gradiente e reinicie com `npx expo start --clear`.

## Tela de Perfil

Acesse pelo login/cadastro com campos válidos ou pela rota `/perfil`. Os dados são fictícios: Nome Sobrenome, nomesobrenome@gmail.com e 7 avaliações.

- Cabeçalho rosa, avatar preparado para receber uma imagem e card branco sobreposto.
- Conquistas Exploradora (7/10), Transformadora (1/3) e Referência (3/10).
- Barras com proporções reais e animação de 650 ms uma vez por montagem.
- Entrada gradual com duração total de até 560 ms para os itens; resposta de toque de 110 ms.
- Barra inferior fixa com Mapa, Eventos, +, Alertas e Perfil ativo.
- Foto, Eventos, + e Alertas exibem aviso de funcionalidade futura.
- Informações pessoais e Configurações abrem rotas de preparação com botão de voltar.
- Sair pede confirmação e retorna ao login; não existe sessão real.
- Sem instalação de bibliotecas adicionais para o Perfil; utiliza Animated e Ionicons existentes.

O fundo da cidade é usado apenas nas rotas de boas-vindas, login e cadastro. A tela de Perfil usa o fundo claro da referência. Todos os campos anteriores preservam a borda rosa de 1 px.

Validação desta versão: TypeScript e bundles Android/iOS aprovados. Não foi possível executar a interface em dispositivo/emulador neste ambiente. Fluidez, aparência final e interação em larguras pequenas precisam de conferência no dispositivo; não há garantia medida de 60 FPS.

## Fluxo de cadastro

Após validar nome, e-mail e senha, o cadastro fecha o teclado, faz fade com subida de 18 pontos por 260 ms e abre `/login`. O login usa a animação de entrada existente. Toques repetidos são bloqueados durante a saída; redução de movimento é respeitada. Nenhuma conta é criada e nenhum dado é enviado ou salvo. O login continua abrindo o Perfil de demonstração.

## Conquistas

No Perfil, toque em Ver mais para abrir `/conquistas`. A tela tem cinco cards conforme a referência: Engajada e Colaboradora concluídas; Exploradora 7/10; Transformadora 1/3; Referência 3/10. Perfil e Conquistas usam os mesmos dados em `constants/achievements.ts` e o mesmo componente `AchievementProgressBar`.

A barra inferior existente agora fica no layout, fora do Stack, e permanece montada entre Perfil e Conquistas. Perfil continua ativo. Toque em Perfil para voltar, ou use o botão/gesto de voltar do sistema.

O card resumido responde com leve aumento de escala antes de abrir a nova rota. Os cards entram com atraso de 45 ms entre si e duração de 320 ms. As barras preenchem em 650 ms após um pequeno atraso. As animações respeitam redução de movimento. Não há backend, persistência ou gamificação real.

Verificação: TypeScript e bundles Android/iOS aprovados. A conferência visual, gestos e fluidez em dispositivo ainda estão pendentes neste ambiente.

## Mapa da cidade

Toque em Mapa na barra inferior. A rota `/mapa` usa `react-native-maps` 1.27.2, compatível com Expo SDK 55. Android usa Google Maps; iOS usa Apple Maps por padrão. Portanto nomes, cores e ruas do mapa podem variar em relação à screenshot do Google Maps.

### Como testar o mapa

Execute `npm ci` e `npx expo start --clear`. Abra no Expo Go compatível com SDK 55 em um celular conectado à internet. Não é necessário configurar chave adicional no Expo Go. Builds próprios de Android exigem configuração de Google Maps antes de publicação, conforme https://docs.expo.dev/versions/v55.0.0/sdk/map-view/ . Nenhuma chave foi incluída neste projeto.

No PC/navegador, o mapa aparece como uma vista estática do centro de Criciúma, com imagens online do OpenStreetMap e pins de demonstração, sem arrastar ou zoom. Requer internet e não precisa de chave de API. A busca local, os filtros e os cards continuam disponíveis. No celular, o componente nativo permanece interativo, com arrastar, zoom e seleção dos pins. Os provedores têm estilos visuais diferentes.

A versão web carrega apenas os tiles visíveis, respeita o cache do navegador e exibe a atribuição do OpenStreetMap. Não armazena mapas para uso offline. Política do serviço: https://operations.osmfoundation.org/policies/tiles/.

### Interações

- Arraste e use zoom no mapa nativo.
- Toque num pin: a seleção ganha destaque e a câmera se move suavemente.
- O card aparece; outro pin troca seu conteúdo com fade; tocar no mapa vazio fecha o card.
- Buscar um lugar filtra os quatro locais de demonstração, ignorando acentos. Use uma sugestão ou Enter para selecionar.
- Filtros abrem um modal e filtram os pins por status de demonstração.
- Ver impactos abre uma rota preparada, com retorno à tela anterior.
- Mapa e Perfil usam a mesma barra inferior persistente. Eventos, Alertas e + continuam preparados para etapa futura.

Os locais e status são dados locais de demonstração; coordenadas são aproximadas. SEGURA/ATENÇÃO não são avaliações reais de segurança e são identificadas como DEMO. Não há GPS, geocoding, Places API, autenticação, persistência ou backend. A foto da Praça Nereu Ramos usa um recorte visual da screenshot fornecida; os demais locais exibem um placeholder.

### Validação desta entrega

TypeScript e exportações Android/iOS/web verificados. Não houve execução em dispositivo ou emulador neste ambiente: carregamento dos tiles, gestos, seleção nativa, teclado e performance precisam ser verificados no celular. Não foi medida a taxa de quadros.

## Eventos

A aba Eventos abre `/eventos`, com o mesmo menu inferior persistente de Mapa e Perfil. Header, tabs internas, votação e workshop seguem a referência fornecida. A aba Consultas tem uma estrutura simples preparada; Alertas agora abre uma rota de preparação.

- Tabs internas: indicador móvel de 280 ms; conteúdo sai em 120 ms e entra em 180 ms.
- Card entra em 320 ms; barras reutilizam o componente de progresso existente, com 650 ms e pequenos atrasos. Valores proporcionais: 29%, 43%, 21%, 7%.
- Seleção local, validação sem opção e confirmação de voto com aviso de demonstração. Trocar entre Eventos e Consultas preserva a seleção durante a montagem da tela. Não há voto enviado nem persistência.
- Participar abre o diálogo compartilhado, informando que inscrições ainda não estão disponíveis; nenhuma inscrição real é feita.
- Scroll com espaço inferior para o botão central, safe area e redução de movimento. Sem novas dependências, HTML ou Reanimated.

Validação: TypeScript e exportações Android/iOS/web aprovados. Não houve teste visual ou de gestos em dispositivo/emulador; fluidez e fidelidade final ainda precisam ser conferidas no aparelho.
