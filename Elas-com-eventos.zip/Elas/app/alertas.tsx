import { StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { colors } from '../constants/theme';
import { MotionReveal } from '../components/MotionReveal';
export default function Alerts() {
  const insets = useSafeAreaInsets();
  return <View style={styles.root}><StatusBar style="light" /><View style={[styles.header, { paddingTop: insets.top + 23 }]}><Text style={styles.title}>Alertas</Text></View><MotionReveal duration={280} distance={8} style={styles.body}><Text style={styles.text}>Os alertas estarão disponíveis em uma próxima etapa.</Text></MotionReveal></View>;
}
const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: colors.surface }, header: { backgroundColor: colors.pink, borderBottomLeftRadius: 29, borderBottomRightRadius: 29, paddingHorizontal: 19, paddingBottom: 18 }, title: { color: colors.white, fontSize: 22, fontWeight: '700' }, body: { padding: 26 }, text: { color: colors.wine, fontSize: 16, lineHeight: 24 } });
