import { ProfileDestination } from '../components/ProfileDestination';
export default function Impacts() { return <ProfileDestination title="Impactos" />; }
