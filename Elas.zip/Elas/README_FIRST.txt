ELAS - COMO ABRIR
=================

1. Extraia a pasta "Elas" inteira.
2. No Windows, dê dois cliques em START_ELAS.bat.
3. O arquivo:
   - verifica se o Node.js está instalado;
   - se necessário, tenta instalar Node.js LTS pelo winget;
   - o npm vem junto com o Node.js;
   - executa npm install;
   - instala/usa o Expo local do projeto;
   - inicia "npx expo start -c".

IMPORTANTE
----------
Não existe AnimatedSkyline.tsx neste projeto.
Não existe nenhum caminho "../app/assets/predios.png".

Os assets ficam exatamente aqui:
  Elas/assets/predios.png
  Elas/assets/logo-elas.png

As páginas ficam exatamente aqui:
  Elas/app/_layout.tsx
  Elas/app/index.tsx
  Elas/app/login.tsx
  Elas/app/cadastro.tsx

Se alguma instalação antiga estiver atrapalhando:
1. Feche o Expo.
2. Execute RESET_ELAS.bat.
3. Depois execute START_ELAS.bat.

Este projeto é apenas frontend por enquanto.
Login e cadastro não acessam banco de dados.
