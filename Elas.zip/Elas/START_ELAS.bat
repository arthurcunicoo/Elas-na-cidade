\
@echo off
setlocal
cd /d "%~dp0"
title Elas - Setup e Expo

echo.
echo ==========================================
echo              ELAS - SETUP
echo ==========================================
echo.

where node >nul 2>nul
if errorlevel 1 goto INSTALL_NODE

node -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit(a>20||(a===20&&b>=19)?0:1)"
if errorlevel 1 goto INSTALL_NODE

goto NODE_OK

:INSTALL_NODE
echo Node.js LTS nao foi encontrado ou esta muito antigo.
echo Expo SDK 54 precisa de Node 20.19 ou mais novo.
echo.

where winget >nul 2>nul
if errorlevel 1 (
  echo Nao consegui instalar automaticamente porque o Windows Package Manager nao foi encontrado.
  echo Instale o Node.js LTS e depois abra este arquivo novamente.
  pause
  exit /b 1
)

echo Instalando Node.js LTS (o npm vem junto)...
winget install OpenJS.NodeJS.LTS -e --accept-source-agreements --accept-package-agreements
if errorlevel 1 (
  echo.
  echo A instalacao do Node.js falhou.
  pause
  exit /b 1
)

set "PATH=C:\Program Files\nodejs;%PATH%"

:NODE_OK
echo Node:
node --version
echo npm:
call npm --version
echo.

if not exist node_modules (
  echo Instalando Expo e as dependencias do projeto...
  echo Isso pode levar alguns minutos na primeira vez.
  call npm install
  if errorlevel 1 (
    echo.
    echo npm install falhou.
    echo Tente executar RESET_ELAS.bat e depois START_ELAS.bat novamente.
    pause
    exit /b 1
  )
) else (
  echo Dependencias ja encontradas.
)

echo.
echo Verificando as versoes do Expo...
call npx expo install --check
echo.
echo Iniciando o Elas com cache limpo...
call npx expo start -c

endlocal
