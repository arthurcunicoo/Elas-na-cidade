\
@echo off
setlocal
cd /d "%~dp0"
title Elas - Reset

echo Fechando caches locais do projeto...
if exist .expo rmdir /s /q .expo
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del /q package-lock.json

echo Limpando cache do npm...
call npm cache verify

echo.
echo Reset concluido.
echo Agora abra START_ELAS.bat.
pause
endlocal
