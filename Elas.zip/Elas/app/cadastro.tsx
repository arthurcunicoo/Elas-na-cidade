import React, { useEffect, useRef, useState } from "react";
import { Alert, Animated, Image, KeyboardAvoidingView, Platform, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View } from "react-native";
import { router } from "expo-router";

const COLORS = { wine: "#760B20", pink: "#C91D50", cream: "#FFF1F2", white: "#FFFFFF" };

export default function Cadastro() {
  const skylineY = useRef(new Animated.Value(105)).current;
  const formY = useRef(new Animated.Value(24)).current;
  const formOpacity = useRef(new Animated.Value(0)).current;
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    Animated.parallel([
      Animated.timing(skylineY, { toValue: 0, duration: 560, useNativeDriver: true }),
      Animated.spring(formY, { toValue: 0, damping: 18, stiffness: 150, mass: 0.8, useNativeDriver: true }),
      Animated.timing(formOpacity, { toValue: 1, duration: 420, delay: 120, useNativeDriver: true }),
    ]).start();
  }, []);

  function createAccount() {
    Alert.alert("Protótipo visual", "O cadastro real entra quando você adicionar o backend.");
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <Animated.View style={[styles.skylineWrap, { transform: [{ translateY: skylineY }] }]}>
          <Image source={require("../assets/predios.png")} resizeMode="cover" style={styles.skyline} />
        </Animated.View>

        <Animated.View style={[styles.form, { opacity: formOpacity, transform: [{ translateY: formY }] }]}>
          <Text style={styles.title}>Faça seu cadastro</Text>

          <Text style={styles.label}>Insira seu nome</Text>
          <TextInput value={name} onChangeText={setName} style={styles.input} selectionColor={COLORS.pink} />

          <Text style={styles.label}>Insira seu e-mail</Text>
          <TextInput value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} style={styles.input} selectionColor={COLORS.pink} />

          <Text style={styles.label}>Insira sua senha</Text>
          <TextInput value={password} onChangeText={setPassword} secureTextEntry style={styles.input} selectionColor={COLORS.pink} />

          <View style={styles.accountRow}>
            <Text style={styles.accountText}>Já possui uma conta? </Text>
            <Pressable onPress={() => router.push("/login")} hitSlop={10}>
              <Text style={styles.link}>Faça login</Text>
            </Pressable>
          </View>

          <Pressable onPress={createAccount} style={({ pressed }) => [styles.button, pressed && styles.pressed]}>
            <Text style={styles.buttonText}>Cadastrar</Text>
          </Pressable>
        </Animated.View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.wine },
  screen: { flex: 1, overflow: "hidden", backgroundColor: COLORS.wine },
  skylineWrap: { position: "absolute", top: 0, left: 0, right: 0, height: "40%", overflow: "hidden" },
  skyline: { width: "100%", height: "100%" },
  form: { position: "absolute", left: 28, right: 28, top: "39%" },
  title: { color: COLORS.white, fontSize: 22, lineHeight: 28, fontWeight: "700", marginBottom: 7 },
  label: { color: COLORS.white, fontSize: 11, fontWeight: "800", marginBottom: 4 },
  input: { minHeight: 50, borderRadius: 14, backgroundColor: COLORS.cream, paddingHorizontal: 14, color: COLORS.wine, fontSize: 16, marginBottom: 8 },
  accountRow: { flexDirection: "row", justifyContent: "center", marginTop: -1, marginBottom: 10 },
  accountText: { color: COLORS.white, fontSize: 10, fontWeight: "700" },
  link: { color: COLORS.white, fontSize: 10, fontWeight: "900", textDecorationLine: "underline" },
  button: { alignSelf: "center", minWidth: 136, minHeight: 43, paddingHorizontal: 18, borderRadius: 10, backgroundColor: COLORS.pink, alignItems: "center", justifyContent: "center" },
  pressed: { opacity: 0.84, transform: [{ scale: 0.985 }] },
  buttonText: { color: COLORS.white, fontSize: 22, fontWeight: "700" },
});
