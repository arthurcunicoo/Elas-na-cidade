import React, { useEffect, useRef, useState } from "react";
import { Alert, Animated, Image, KeyboardAvoidingView, Platform, Pressable, SafeAreaView, StyleSheet, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { router } from "expo-router";

const COLORS = { wine: "#760B20", pink: "#C91D50", cream: "#FFF1F2", white: "#FFFFFF", icon: "#F3BBC6" };

export default function Login() {
  const skylineY = useRef(new Animated.Value(105)).current;
  const formY = useRef(new Animated.Value(24)).current;
  const formOpacity = useRef(new Animated.Value(0)).current;
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  useEffect(() => {
    Animated.parallel([
      Animated.timing(skylineY, { toValue: 0, duration: 560, useNativeDriver: true }),
      Animated.spring(formY, { toValue: 0, damping: 18, stiffness: 150, mass: 0.8, useNativeDriver: true }),
      Animated.timing(formOpacity, { toValue: 1, duration: 420, delay: 120, useNativeDriver: true }),
    ]).start();
  }, []);

  function enter() {
    Alert.alert("Protótipo visual", "O backend ainda não está conectado.");
  }

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined}>
        <Animated.View style={[styles.skylineWrap, { transform: [{ translateY: skylineY }] }]}>
          <Image source={require("../assets/predios.png")} resizeMode="cover" style={styles.skyline} />
        </Animated.View>

        <Animated.View style={[styles.form, { opacity: formOpacity, transform: [{ translateY: formY }] }]}>
          <Text style={styles.title}>Faça seu Login</Text>

          <Text style={styles.label}>Digite seu e-mail</Text>
          <View style={styles.inputBox}>
            <Ionicons name="person-circle-outline" size={27} color={COLORS.icon} style={styles.icon} />
            <TextInput value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" autoCorrect={false} style={styles.input} selectionColor={COLORS.pink} />
          </View>

          <Text style={styles.label}>Digite sua senha</Text>
          <View style={styles.inputBox}>
            <Ionicons name="lock-closed" size={18} color={COLORS.icon} style={styles.icon} />
            <TextInput value={password} onChangeText={setPassword} secureTextEntry style={styles.input} selectionColor={COLORS.pink} />
          </View>

          <View style={styles.accountRow}>
            <Text style={styles.accountText}>Não possui conta? </Text>
            <Pressable onPress={() => router.push("/cadastro")} hitSlop={10}>
              <Text style={styles.link}>Cadastrar</Text>
            </Pressable>
          </View>

          <Pressable onPress={enter} style={({ pressed }) => [styles.button, pressed && styles.pressed]}>
            <Text style={styles.buttonText}>Entrar</Text>
          </Pressable>
        </Animated.View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.wine },
  screen: { flex: 1, overflow: "hidden", backgroundColor: COLORS.wine },
  skylineWrap: { position: "absolute", top: 0, left: 0, right: 0, height: "40%", overflow: "hidden" },
  skyline: { width: "100%", height: "100%" },
  form: { position: "absolute", left: 25, right: 25, top: "41.5%" },
  title: { color: COLORS.white, fontSize: 22, lineHeight: 28, fontWeight: "700", marginBottom: 11 },
  label: { color: COLORS.white, fontSize: 12, fontWeight: "800", marginBottom: 5 },
  inputBox: { minHeight: 52, borderRadius: 14, backgroundColor: COLORS.cream, flexDirection: "row", alignItems: "center", marginBottom: 11 },
  icon: { marginLeft: 10, marginRight: 4 },
  input: { flex: 1, minHeight: 52, paddingHorizontal: 6, paddingRight: 14, color: COLORS.wine, fontSize: 16 },
  accountRow: { flexDirection: "row", justifyContent: "center", marginBottom: 10 },
  accountText: { color: COLORS.white, fontSize: 11, fontWeight: "700" },
  link: { color: COLORS.white, fontSize: 11, fontWeight: "900", textDecorationLine: "underline" },
  button: { alignSelf: "center", minWidth: 136, minHeight: 43, paddingHorizontal: 24, borderRadius: 10, backgroundColor: COLORS.pink, alignItems: "center", justifyContent: "center" },
  pressed: { opacity: 0.84, transform: [{ scale: 0.985 }] },
  buttonText: { color: COLORS.white, fontSize: 22, fontWeight: "700" },
});
