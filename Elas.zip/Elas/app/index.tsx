import React, { useRef, useState } from "react";
import { Animated, Image, Pressable, SafeAreaView, StyleSheet, Text, useWindowDimensions, View } from "react-native";
import { router } from "expo-router";

const COLORS = { cream: "#FFF1F2", wine: "#760B20", pink: "#C91D50", white: "#FFFFFF" };

export default function Index() {
  const { height } = useWindowDimensions();
  const skylineY = useRef(new Animated.Value(0)).current;
  const skylineScale = useRef(new Animated.Value(1)).current;
  const contentOpacity = useRef(new Animated.Value(1)).current;
  const [animating, setAnimating] = useState(false);

  function goToLogin() {
    if (animating) return;
    setAnimating(true);

    Animated.parallel([
      Animated.timing(skylineY, { toValue: -220, duration: 620, useNativeDriver: true }),
      Animated.timing(skylineScale, { toValue: 1.04, duration: 620, useNativeDriver: true }),
      Animated.timing(contentOpacity, { toValue: 0, duration: 330, useNativeDriver: true }),
    ]).start(({ finished }) => {
      if (finished) router.push("/login");

      setTimeout(() => {
        skylineY.setValue(0);
        skylineScale.setValue(1);
        contentOpacity.setValue(1);
        setAnimating(false);
      }, 400);
    });
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.screen}>
        <View style={styles.creamArea} />
        <View style={styles.wineArea} />

        <Animated.View style={[styles.logoWrap, { opacity: contentOpacity }]}>
          <Image source={require("../assets/logo-elas.png")} resizeMode="contain" style={[styles.logo, { width: Math.min(235, height * 0.38) }]} />
        </Animated.View>

        <Animated.View style={[styles.skylineWrap, { height: Math.max(255, height * 0.43), transform: [{ translateY: skylineY }, { scale: skylineScale }] }]}>
          <Image source={require("../assets/predios.png")} resizeMode="cover" style={styles.skyline} />
        </Animated.View>

        <Animated.View style={[styles.actions, { opacity: contentOpacity }]}>
          <Pressable onPress={goToLogin} disabled={animating} style={({ pressed }) => [styles.button, pressed && styles.pressed]}>
            <Text style={styles.buttonText}>Começar</Text>
          </Pressable>

          <View style={styles.accountRow}>
            <Text style={styles.accountText}>Não possui conta? </Text>
            <Pressable onPress={() => router.push("/cadastro")} hitSlop={10}>
              <Text style={styles.link}>Cadastrar</Text>
            </Pressable>
          </View>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: COLORS.cream },
  screen: { flex: 1, overflow: "hidden", backgroundColor: COLORS.cream },
  creamArea: { ...StyleSheet.absoluteFillObject, backgroundColor: COLORS.cream },
  wineArea: { position: "absolute", left: 0, right: 0, bottom: 0, height: "43%", backgroundColor: COLORS.wine },
  logoWrap: { position: "absolute", top: "2.5%", left: 0, right: 0, zIndex: 3, alignItems: "center" },
  logo: { height: 135 },
  skylineWrap: { position: "absolute", top: "25.5%", left: 0, right: 0, zIndex: 2, overflow: "hidden" },
  skyline: { width: "100%", height: "100%" },
  actions: { position: "absolute", left: 28, right: 28, bottom: 54, zIndex: 4, alignItems: "center" },
  button: { width: "78%", minHeight: 53, borderRadius: 11, backgroundColor: COLORS.pink, alignItems: "center", justifyContent: "center" },
  pressed: { opacity: 0.84, transform: [{ scale: 0.985 }] },
  buttonText: { color: COLORS.white, fontSize: 24, fontWeight: "700" },
  accountRow: { flexDirection: "row", justifyContent: "center", marginTop: 8 },
  accountText: { color: COLORS.white, fontSize: 12, fontWeight: "700" },
  link: { color: COLORS.white, fontSize: 12, fontWeight: "900", textDecorationLine: "underline" },
});
