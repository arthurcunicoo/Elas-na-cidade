# ELAS na cidade — fundo novo e animações

App mobile com React Native, TypeScript, Expo SDK 55 e Expo Router.

## Iniciar

Extraia o ZIP em uma pasta nova. Dentro de Elas, execute:

```sh
npm ci
npx expo start --clear
```

Requer Node.js 22 LTS ou superior e Expo Go compatível com SDK 55, ou um ambiente nativo configurado. A prévia no navegador pode ser aberta com `npx expo start --web`. Os componentes do app continuam sendo React Native.

## O que mudou nesta versão

- Fundo substituído pelo JPG fornecido, em `assets/city-modern.jpg`.
- Imagem preserva proporções e preenche a área da cidade, recortando as laterais quando necessário.
- Movimento horizontal lento do cenário com margem de imagem para não mostrar bordas.
- Subida com mola amortecida das boas-vindas para os formulários. Login e cadastro mantêm a mesma altura da cidade.
- Entrada do logo e dos campos em sequência, repetida ao retornar à tela.
- Botões comprimem no toque e retornam com mola.
- Transição visual entre a cidade e a área vinho dos formulários.
- Fundo de navegação transparente e inputs sem contorno retangular laranja.
- Redução de movimento respeitada; loops e animações são interrompidos ao desmontar.

## Estrutura

- `app/index.tsx`: boas-vindas.
- `app/login.tsx`: login.
- `app/cadastro.tsx`: cadastro.
- `components/CitySkyline.tsx`: cenário compartilhado e animado.
- `components/MotionReveal.tsx`: entrada dos elementos ao focar uma tela.
- `components/PrimaryButton.tsx`: botão com resposta ao toque.
- `hooks/useReducedMotion.ts`: preferência de acessibilidade.

O logo usa o recorte visual da screenshot original. Login e cadastro apenas validam os dados e mostram um aviso; não há autenticação nem transmissão de dados.

## Verificação

TypeScript e exportação Metro/Hermes Android e iOS. Sem execução visual em emulador ou celular neste ambiente; o resultado visual e o comportamento do teclado ainda precisam ser conferidos no dispositivo.

```sh
npm run typecheck
npx expo export --platform android --platform ios
```

## Ajuste das emendas

A transição da imagem para o fundo usa `expo-linear-gradient`, com opacidade total nas bordas e as cores exatas do fundo. As antigas faixas sobrepostas foram removidas. O topo mistura a imagem com o creme e a base termina em vinho sólido antes da junção.

`constants/cityLayout.ts` centraliza as medidas: login e cadastro compartilham o mesmo nível de cidade e início do formulário. As demais animações permanecem.

Ao atualizar, execute `npm ci` para instalar a dependência do gradiente e reinicie com `npx expo start --clear`.
