export const colors = { cream: '#FFF2F2', wine: '#760B20', cityWine: '#760A22', pink: '#BD1C51', white: '#FFFFFF', icon: '#EDA1B8' };
