import { PropsWithChildren, useRef } from 'react';
import { Animated, Platform, Pressable, StyleProp, ViewStyle } from 'react-native';
import { useReducedMotion } from '../hooks/useReducedMotion';
type Props = PropsWithChildren<{ onPress: () => void; label: string; selected?: boolean; style?: StyleProp<ViewStyle> }>;
export function TouchFeedback({ children, onPress, label, selected, style }: Props) {
  const scale = useRef(new Animated.Value(1)).current;
  const reduced = useReducedMotion();
  function animate(toValue: number) {
    Animated.timing(scale, { toValue: reduced ? 1 : toValue, duration: 110, useNativeDriver: Platform.OS !== 'web' }).start();
  }
  return <Animated.View style={[style, { transform: [{ scale }] }]}><Pressable accessibilityRole="button" accessibilityLabel={label} accessibilityState={{ selected }} onPress={onPress} onPressIn={() => animate(.97)} onPressOut={() => animate(1)} style={({ pressed }) => ({ opacity: pressed ? .78 : 1, flexGrow: 1, justifyContent: 'center' })}>{children}</Pressable></Animated.View>;
}
