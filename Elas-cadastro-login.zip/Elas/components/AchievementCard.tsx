import { useEffect, useRef } from 'react';
import { Animated, Easing, StyleSheet, Text, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../constants/theme';
import { useReducedMotion } from '../hooks/useReducedMotion';
import { TouchFeedback } from './TouchFeedback';
const achievements = [
  { title: 'Exploradora', description: 'Avaliou 10 locais diferentes', value: 7, total: 10, icon: 'globe-outline' },
  { title: 'Transformadora', description: 'Contribuiu para 3 melhorias', value: 1, total: 3, icon: 'bar-chart-outline' },
  { title: 'Referência', description: 'Teve 10 avaliações úteis', value: 2, total: 10, icon: 'trophy-outline' },
] as const;
function ProgressBar({ value, total }: { value: number; total: number }) {
  const reduced = useReducedMotion();
  const progress = useRef(new Animated.Value(value / total)).current;
  const played = useRef(false);
  useEffect(() => {
    if (reduced) { progress.stopAnimation(); progress.setValue(value / total); return; }
    if (played.current) return;
    played.current = true;
    progress.setValue(0);
    const animation = Animated.timing(progress, { toValue: value / total, duration: 650, easing: Easing.out(Easing.cubic), useNativeDriver: false });
    animation.start();
    return () => { animation.stop(); progress.setValue(value / total); };
  }, [progress, reduced, total, value]);
  return <View style={styles.progressRow} accessible accessibilityRole="progressbar" accessibilityValue={{ min: 0, max: total, now: value, text: `${value} de ${total}` }}><View style={styles.track}><Animated.View style={[styles.fill, { width: progress.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] }) }]} /></View><Text style={styles.count}>{value}/{total}</Text></View>;
}
export function AchievementCard({ onMore }: { onMore: () => void }) {
  return <View style={styles.card}>
    <Text style={styles.number}>7</Text><Text style={styles.reviews}>Avaliações</Text>
    <Text style={styles.heading}>Conquistas</Text>
    {achievements.map(item => <View key={item.title} style={styles.row}><Ionicons name={item.icon} size={28} color={colors.achievement} style={{ marginTop: 2 }} /><View style={styles.detail}><Text style={styles.title}>{item.title}</Text><Text style={styles.description}>{item.description}</Text><ProgressBar value={item.value} total={item.total} /></View></View>)}
    <TouchFeedback label="Ver mais conquistas" onPress={onMore} style={styles.more}><Text style={styles.moreText}>Ver mais</Text></TouchFeedback>
  </View>;
}
const styles = StyleSheet.create({ card: { backgroundColor: colors.white, borderRadius: 21, paddingHorizontal: 24, paddingTop: 10, paddingBottom: 0, shadowColor: '#000', shadowOpacity: .15, shadowRadius: 6, shadowOffset: { width: 0, height: 3 }, elevation: 4 }, number: { color: colors.wine, fontSize: 18, fontWeight: '700', textAlign: 'center' }, reviews: { color: colors.wine, fontSize: 16, textAlign: 'center', marginTop: 2 }, heading: { color: colors.wine, fontSize: 16, fontWeight: '600', marginTop: 10, marginBottom: 10 }, row: { flexDirection: 'row', gap: 9, marginBottom: 14 }, detail: { flex: 1 }, title: { color: colors.wine, fontSize: 13, fontWeight: '700' }, description: { color: colors.wine, fontSize: 10, fontWeight: '500', marginTop: 1 }, progressRow: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 9 }, track: { flex: 1, height: 7, backgroundColor: '#EAEAEA', borderRadius: 5, overflow: 'hidden' }, fill: { height: '100%', backgroundColor: colors.pink, borderRadius: 5 }, count: { color: colors.wine, fontSize: 9, fontWeight: '700', minWidth: 26 }, more: { alignSelf: 'center', minHeight: 44, marginTop: -14, paddingHorizontal: 18 }, moreText: { color: colors.pink, fontSize: 13, fontWeight: '700', textAlign: 'center', backgroundColor: colors.cream, borderRadius: 5, paddingHorizontal: 5, paddingVertical: 2 } });
