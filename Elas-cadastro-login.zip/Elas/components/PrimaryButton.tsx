import { useRef } from 'react';
import { Animated, Platform, Pressable, StyleSheet, Text } from 'react-native';
import { useReducedMotion } from '../hooks/useReducedMotion';
import { colors } from '../constants/theme';
export function PrimaryButton({ title, onPress, wide = false }: { title: string; onPress: () => void; wide?: boolean }) {
  const scale = useRef(new Animated.Value(1)).current;
  const reduced = useReducedMotion();
  function animate(value: number) {
    if (reduced) { scale.setValue(1); return; }
    Animated.spring(scale, { toValue: value, damping: 12, stiffness: 260, mass: .7, useNativeDriver: Platform.OS !== 'web' }).start();
  }
  return <Animated.View style={{ alignSelf: 'center', width: wide ? '67%' : '64%', transform: [{ scale }] }}>
    <Pressable accessibilityRole="button" onPress={onPress} onPressIn={() => animate(.94)} onPressOut={() => animate(1)} style={({ pressed }) => [styles.button, { opacity: pressed ? .9 : 1 }]}><Text style={styles.text}>{title}</Text></Pressable>
  </Animated.View>;
}
const styles = StyleSheet.create({ button: { alignItems: 'center', justifyContent: 'center', backgroundColor: colors.pink, borderRadius: 17, minHeight: 52, paddingVertical: 9, paddingHorizontal: 12, shadowColor: '#390416', shadowOffset: { width: 0, height: 6 }, shadowRadius: 12, shadowOpacity: .2, elevation: 4 }, text: { color: colors.white, fontSize: 27, fontWeight: '600' } });
