# ELAS na cidade — fundo novo e animações

App mobile com React Native, TypeScript, Expo SDK 55 e Expo Router.

## Iniciar

Extraia o ZIP em uma pasta nova. Dentro de Elas, execute:

```sh
npm ci
npx expo start --clear
```

Requer Node.js 22 LTS ou superior e Expo Go compatível com SDK 55, ou um ambiente nativo configurado. A prévia no navegador pode ser aberta com `npx expo start --web`. Os componentes do app continuam sendo React Native.

## O que mudou nesta versão

- Fundo substituído pelo JPG fornecido, em `assets/city-modern.jpg`.
- Imagem preserva proporções e preenche a área da cidade, recortando as laterais quando necessário.
- Movimento horizontal lento do cenário com margem de imagem para não mostrar bordas.
- Subida com mola amortecida das boas-vindas para os formulários. Login e cadastro mantêm a mesma altura da cidade.
- Entrada do logo e dos campos em sequência, repetida ao retornar à tela.
- Botões comprimem no toque e retornam com mola.
- Transição visual entre a cidade e a área vinho dos formulários.
- Fundo de navegação transparente e inputs sem contorno retangular laranja.
- Redução de movimento respeitada; loops e animações são interrompidos ao desmontar.

## Estrutura

- `app/index.tsx`: boas-vindas.
- `app/login.tsx`: login.
- `app/cadastro.tsx`: cadastro.
- `components/CitySkyline.tsx`: cenário compartilhado e animado.
- `components/MotionReveal.tsx`: entrada dos elementos ao focar uma tela.
- `components/PrimaryButton.tsx`: botão com resposta ao toque.
- `hooks/useReducedMotion.ts`: preferência de acessibilidade.

O logo usa o recorte visual da screenshot original. Login abre o Perfil de demonstração; cadastro valida os campos, anima a saída do formulário e retorna ao login; não há autenticação nem transmissão de dados.

## Verificação

TypeScript e exportação Metro/Hermes Android e iOS. Sem execução visual em emulador ou celular neste ambiente; o resultado visual e o comportamento do teclado ainda precisam ser conferidos no dispositivo.

```sh
npm run typecheck
npx expo export --platform android --platform ios
```

## Ajuste das emendas

A transição da imagem para o fundo usa `expo-linear-gradient`, com opacidade total nas bordas e as cores exatas do fundo. As antigas faixas sobrepostas foram removidas. O topo mistura a imagem com o creme e a base termina em vinho sólido antes da junção.

`constants/cityLayout.ts` centraliza as medidas: login e cadastro compartilham o mesmo nível de cidade e início do formulário. As demais animações permanecem.

Ao atualizar, execute `npm ci` para instalar a dependência do gradiente e reinicie com `npx expo start --clear`.

## Tela de Perfil

Acesse pelo login/cadastro com campos válidos ou pela rota `/perfil`. Os dados são fictícios: Nome Sobrenome, nomesobrenome@gmail.com e 7 avaliações.

- Cabeçalho rosa, avatar preparado para receber uma imagem e card branco sobreposto.
- Conquistas Exploradora (7/10), Transformadora (1/3) e Referência (2/10).
- Barras com proporções reais e animação de 650 ms uma vez por montagem.
- Entrada gradual com duração total de até 560 ms para os itens; resposta de toque de 110 ms.
- Barra inferior fixa com Mapa, Eventos, +, Alertas e Perfil ativo.
- Foto, Ver mais, Mapa, Eventos, + e Alertas exibem aviso de funcionalidade futura.
- Informações pessoais e Configurações abrem rotas de preparação com botão de voltar.
- Sair pede confirmação e retorna ao login; não existe sessão real.
- Sem instalação de bibliotecas adicionais para o Perfil; utiliza Animated e Ionicons existentes.

O fundo da cidade é usado apenas nas rotas de boas-vindas, login e cadastro. A tela de Perfil usa o fundo claro da referência. Todos os campos anteriores preservam a borda rosa de 1 px.

Validação desta versão: TypeScript e bundles Android/iOS aprovados. Não foi possível executar a interface em dispositivo/emulador neste ambiente. Fluidez, aparência final e interação em larguras pequenas precisam de conferência no dispositivo; não há garantia medida de 60 FPS.

## Fluxo de cadastro

Após validar nome, e-mail e senha, o cadastro fecha o teclado, faz fade com subida de 18 pontos por 260 ms e abre `/login`. O login usa a animação de entrada existente. Toques repetidos são bloqueados durante a saída; redução de movimento é respeitada. Nenhuma conta é criada e nenhum dado é enviado ou salvo. O login continua abrindo o Perfil de demonstração.
