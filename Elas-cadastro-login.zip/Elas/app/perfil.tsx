import { useState } from 'react';
import { ScrollView, StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { ProfileHeader } from '../components/ProfileHeader';
import { AchievementCard } from '../components/AchievementCard';
import { ProfileMenuItem } from '../components/ProfileMenuItem';
import { BottomNavigation } from '../components/BottomNavigation';
import { ProfileDialog, ProfileNotice } from '../components/ProfileDialog';
import { MotionReveal } from '../components/MotionReveal';
import { colors } from '../constants/theme';
export default function Profile() {
  const [notice, setNotice] = useState<ProfileNotice | null>(null);
  function pending(title: string) { setNotice({ title, message: 'Esta funcionalidade estará disponível em uma próxima etapa.' }); }
  function handleLogout() { setNotice({ title: 'Sair do perfil?', message: 'Você voltará para a tela de login.', confirm: () => router.replace('/login') }); }
  return <View style={styles.root}><StatusBar style="light" />
    <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
      <ProfileHeader onEdit={() => pending('Alterar foto')} />
      <View style={styles.body}>
        <MotionReveal duration={360} delay={80} distance={20} style={styles.overlap}><AchievementCard onMore={() => pending('Mais conquistas')} /></MotionReveal>
        <View style={styles.menu}>
          <MotionReveal duration={320} delay={140} distance={12}><ProfileMenuItem title="Informações pessoais" icon="pencil" onPress={() => router.push('/informacoes-pessoais')} /></MotionReveal>
          <MotionReveal duration={320} delay={190} distance={12}><ProfileMenuItem title="Configurações" icon="settings" onPress={() => router.push('/configuracoes')} /></MotionReveal>
          <MotionReveal duration={320} delay={240} distance={12}><ProfileMenuItem title="Sair" icon="log-out" onPress={handleLogout} /></MotionReveal>
        </View>
      </View>
    </ScrollView>
    <BottomNavigation onAction={label => { if (label !== 'Perfil') pending(label === 'Adicionar' ? 'Adicionar avaliação' : label); }} />
    <ProfileDialog notice={notice} onClose={() => setNotice(null)} />
  </View>;
}
const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: colors.surface }, scroll: { flexGrow: 1, paddingBottom: 40 }, body: { width: '84%', maxWidth: 440, alignSelf: 'center' }, overlap: { marginTop: -52 }, menu: { marginTop: 10, gap: 8 } });
