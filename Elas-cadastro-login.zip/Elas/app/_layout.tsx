import { DefaultTheme, ThemeProvider } from '@react-navigation/native';
import { colors } from '../constants/theme';
import { Stack, usePathname } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { StyleSheet, View } from 'react-native';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { CitySkyline } from '../components/CitySkyline';
const theme = { ...DefaultTheme, colors: { ...DefaultTheme.colors, background: 'transparent' } };
export default function RootLayout() {
  const path = usePathname();
  const authScreen = ['/', '/login', '/cadastro'].includes(path);
  return <SafeAreaProvider><ThemeProvider value={theme}><View style={styles.root}><StatusBar style="dark" />{authScreen && <CitySkyline />}
    <Stack screenOptions={{ headerShown: false, animation: 'fade', contentStyle: { backgroundColor: 'transparent' } }} />
  </View></ThemeProvider></SafeAreaProvider>;
}
const styles = StyleSheet.create({ root: { flex: 1, backgroundColor: colors.cream, overflow: 'hidden' } });
